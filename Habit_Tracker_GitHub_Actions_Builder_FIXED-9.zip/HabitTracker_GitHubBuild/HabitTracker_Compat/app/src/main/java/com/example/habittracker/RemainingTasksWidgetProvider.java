package com.example.habittracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class RemainingTasksWidgetProvider extends AppWidgetProvider {
    public static void updateAll(Context c) {
        AppWidgetManager manager = AppWidgetManager.getInstance(c);
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, RemainingTasksWidgetProvider.class));
        for (int id : ids) updateOne(c, manager, id);
    }
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(c, manager, id);
    }
    private static void updateOne(Context c, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(c.getPackageName(), R.layout.remaining_tasks_widget);
        try {
            String raw = c.getSharedPreferences(HabitWidgetProvider.PREFS, Context.MODE_PRIVATE).getString(HabitWidgetProvider.STATE, "{}");
            JSONObject state = new JSONObject(raw);
            JSONArray habits = state.optJSONArray("habits");
            JSONObject checks = state.optJSONObject("checks");
            if (checks == null) checks = new JSONObject();
            Calendar now = Calendar.getInstance();
            String month = new SimpleDateFormat("yyyy-MM", Locale.US).format(now.getTime());
            int day = now.get(Calendar.DAY_OF_MONTH);
            int total = habits == null ? 0 : habits.length(), done = 0;
            for (int i = 0; i < total; i++) if (checks.optInt(month + "|" + i + "|" + day, 0) == 1) done++;
            int remaining = Math.max(0, total - done);
            views.setTextViewText(R.id.remaining_title, "TASKS REMAINING");
            views.setTextViewText(R.id.remaining_count, String.valueOf(remaining));
            views.setTextViewText(R.id.remaining_detail, remaining == 1 ? "task left to complete" : "tasks left to complete");
            views.setTextViewText(R.id.remaining_progress, done + " of " + total + " completed today");
        } catch (Exception e) {
            views.setTextViewText(R.id.remaining_title, "TASKS REMAINING");
            views.setTextViewText(R.id.remaining_count, "—");
            views.setTextViewText(R.id.remaining_detail, "Open tracker to refresh");
            views.setTextViewText(R.id.remaining_progress, "");
        }
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 9200 + id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.remaining_root, pi);
        manager.updateAppWidget(id, views);
    }
}

package com.example.habittracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501); }
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new WidgetBridge(), "AndroidWidget");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            String raw = getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).getString(HabitWidgetProvider.STATE, "");
            if (raw != null && !raw.isEmpty()) webView.evaluateJavascript("if(window.applyNativeState)window.applyNativeState(" + JSONObject.quote(raw) + ")", null);
        }
    }
    private class WidgetBridge {
        @JavascriptInterface public String getState() {
            return getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).getString(HabitWidgetProvider.STATE, "");
        }
        @JavascriptInterface public void syncState(String json) {
            getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).edit().putString(HabitWidgetProvider.STATE, json).apply();
            HabitWidgetProvider.updateAll(MainActivity.this);
        }
        @JavascriptInterface public void scheduleReminder(int index, String habit, String time) { ReminderScheduler.schedule(MainActivity.this, index, habit, time); }
        @JavascriptInterface public void cancelReminder(int index) { ReminderScheduler.cancel(MainActivity.this, index); }
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}

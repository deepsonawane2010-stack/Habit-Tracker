package com.example.habittracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class HabitWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "habit_widget_prefs";
    public static final String STATE = "state";
    public static final String ACTION_TOGGLE = "com.example.habittracker.TOGGLE_TASK";
    public static final String EXTRA_INDEX = "habit_index";

    public static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, HabitWidgetProvider.class));
        for (int id : ids) safeUpdate(c, m, id);
        RemainingTasksWidgetProvider.updateAll(c);
    }
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) safeUpdate(c, m, id); }
    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            int index = intent.getIntExtra(EXTRA_INDEX, -1);
            try {
                android.content.SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                JSONObject state = new JSONObject(p.getString(STATE, "{}"));
                JSONArray habits = state.optJSONArray("habits");
                JSONObject checks = state.optJSONObject("checks"); if (checks == null) checks = new JSONObject();
                if (habits != null && index >= 0 && index < habits.length()) {
                    Calendar now = Calendar.getInstance();
                    String month = new SimpleDateFormat("yyyy-MM", Locale.US).format(now.getTime());
                    int day = now.get(Calendar.DAY_OF_MONTH);
                    String key = month + "|" + index + "|" + day;
                    if (checks.optInt(key, 0) == 1) checks.remove(key); else checks.put(key, 1);
                    state.put("checks", checks); p.edit().putString(STATE, state.toString()).apply();
                }
            } catch (Exception ignored) {}
            updateAll(c);
        }
    }
    private static void safeUpdate(Context c, AppWidgetManager m, int id) {
        try { update(c, m, id); } catch (Throwable e) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.habit_widget);
            v.setTextViewText(R.id.widget_title, "TODAY'S TASKS");
            v.setTextViewText(R.id.widget_progress, "Open tracker to refresh");
            v.setTextViewText(R.id.widget_streak, ""); v.setTextViewText(R.id.widget_events, "");
            setOpenIntent(c, v, id); m.updateAppWidget(id, v);
        }
    }
    private static void update(Context c, AppWidgetManager m, int id) throws Exception {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.habit_widget);
        String raw = c.getSharedPreferences(PREFS, 0).getString(STATE, "{}");
        JSONObject state = new JSONObject(raw); JSONArray habits = state.optJSONArray("habits");
        JSONObject checks = state.optJSONObject("checks"); if (checks == null) checks = new JSONObject();
        JSONObject events = state.optJSONObject("events");
        Calendar now = Calendar.getInstance();
        String month = new SimpleDateFormat("yyyy-MM", Locale.US).format(now.getTime());
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now.getTime()); int day = now.get(Calendar.DAY_OF_MONTH);
        int count = habits == null ? 0 : habits.length(), done = 0, bestStreak = 0;
        v.removeAllViews(R.id.widget_task_rows);
        int shown = Math.min(count, 5);
        for (int i = 0; i < count; i++) {
            String key = month + "|" + i + "|" + day; boolean checked = checks.optInt(key, 0) == 1; if (checked) done++;
            int run = 0; for (int d = day; d >= 1; d--) { if (checks.optInt(month + "|" + i + "|" + d, 0) == 1) run++; else break; } bestStreak = Math.max(bestStreak, run);
            if (i < shown) {
                RemoteViews row = new RemoteViews(c.getPackageName(), R.layout.habit_widget_row);
                row.setTextViewText(R.id.widget_task_name, (checked ? "✓  " : "") + habits.optString(i, "Task"));
                row.setTextViewText(R.id.widget_task_check, checked ? "✓" : "");
                Intent toggle = new Intent(c, HabitWidgetProvider.class); toggle.setAction(ACTION_TOGGLE); toggle.putExtra(EXTRA_INDEX, i);
                PendingIntent tp = PendingIntent.getBroadcast(c, 5000 + i, toggle, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                row.setOnClickPendingIntent(R.id.widget_task_row, tp); row.setOnClickPendingIntent(R.id.widget_task_check, tp);
                v.addView(R.id.widget_task_rows, row);
            }
        }
        v.setTextViewText(R.id.widget_title, "TODAY'S TASKS");
        v.setTextViewText(R.id.widget_progress, "Today: " + done + "/" + count + " completed");
        v.setTextViewText(R.id.widget_streak, "Best streak: " + bestStreak + " day" + (bestStreak == 1 ? "" : "s"));
        StringBuilder eventText = new StringBuilder(); JSONArray todays = events == null ? null : events.optJSONArray(date);
        if (todays != null) for (int i = 0; i < Math.min(2, todays.length()); i++) { if (i > 0) eventText.append(" • "); eventText.append(todays.optString(i, "Event")); }
        v.setTextViewText(R.id.widget_events, eventText.length() == 0 ? (count > shown ? "+" + (count - shown) + " more tasks" : "Tap a checkbox to complete") : eventText.toString());
        setOpenIntent(c, v, id); m.updateAppWidget(id, v);
    }
    private static void setOpenIntent(Context c, RemoteViews v, int id) {
        Intent in = new Intent(c, MainActivity.class); PendingIntent p = PendingIntent.getActivity(c, id, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, p); v.setOnClickPendingIntent(R.id.widget_open, p);
    }
}

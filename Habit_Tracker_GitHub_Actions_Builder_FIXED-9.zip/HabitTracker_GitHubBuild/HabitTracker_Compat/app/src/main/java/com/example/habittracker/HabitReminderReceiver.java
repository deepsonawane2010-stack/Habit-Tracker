package com.example.habittracker;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class HabitReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String habit=intent.getStringExtra("habit_name"); if(habit==null || habit.trim().isEmpty()) habit="Your habit";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("habit_reminders","Habit reminders",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(context,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b;
        if(Build.VERSION.SDK_INT>=26) b=new android.app.Notification.Builder(context,"habit_reminders"); else b=new android.app.Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_launcher).setContentTitle("Habit reminder").setContentText("Time for: "+habit).setAutoCancel(true).setContentIntent(pi);
        nm.notify(9000+intent.getIntExtra("habit_index",0),b.build());
        int index=intent.getIntExtra("habit_index",-1); if(index>=0){String name=context.getSharedPreferences("habit_reminders",Context.MODE_PRIVATE).getString("name_"+index,habit);String time=context.getSharedPreferences("habit_reminders",Context.MODE_PRIVATE).getString("time_"+index,"");if(!time.isEmpty())ReminderScheduler.schedule(context,index,name,time);}
    }
}

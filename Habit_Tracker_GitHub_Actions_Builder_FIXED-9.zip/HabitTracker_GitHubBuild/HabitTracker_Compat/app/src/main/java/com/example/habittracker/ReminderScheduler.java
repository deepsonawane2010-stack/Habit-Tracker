package com.example.habittracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    static PendingIntent pending(Context c, int index, String habit) {
        Intent i = new Intent(c, HabitReminderReceiver.class);
        i.putExtra("habit_index", index); i.putExtra("habit_name", habit == null ? "Your habit" : habit);
        return PendingIntent.getBroadcast(c, 8000 + index, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c, int index, String habit, String time) {
        try {
            String[] parts = time.split(":"); int hour = Integer.parseInt(parts[0]), minute = Integer.parseInt(parts[1]);
            Calendar when = Calendar.getInstance(); when.set(Calendar.HOUR_OF_DAY, hour); when.set(Calendar.MINUTE, minute); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
            if (when.getTimeInMillis() <= System.currentTimeMillis()) when.add(Calendar.DAY_OF_YEAR, 1);
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi = pending(c,index,habit);
            if (am != null) { if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi); else am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi); }
            c.getSharedPreferences("habit_reminders", Context.MODE_PRIVATE).edit().putString("name_"+index, habit).putString("time_"+index,time).apply();
        } catch (Exception ignored) {}
    }
    public static void cancel(Context c, int index) { try { AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=pending(c,index,""); if(am!=null)am.cancel(pi); pi.cancel(); c.getSharedPreferences("habit_reminders",Context.MODE_PRIVATE).edit().remove("name_"+index).remove("time_"+index).apply(); } catch(Exception ignored){} }
}

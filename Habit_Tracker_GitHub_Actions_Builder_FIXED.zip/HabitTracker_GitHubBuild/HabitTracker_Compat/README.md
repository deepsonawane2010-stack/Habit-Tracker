Habit Tracker - compatibility Android project

This version intentionally uses only the Android Gradle Plugin and platform WebView, with no AndroidX or third-party runtime libraries. It is intended for online Android builders that have common Android/Gradle components cached.

Build output: APK
Application ID: com.example.habittracker

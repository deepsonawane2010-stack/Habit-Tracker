package com.example.habittracker;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class HabitReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_START = "com.example.habittracker.START_HABIT_TIMER";
    public static final String ACTION_STOP = "com.example.habittracker.STOP_HABIT_TIMER";
    private static final String CHANNEL = "habit_reminders_sound_v2";
    private static final String PREFS = "habit_timer_sessions";

    @Override public void onReceive(Context context, Intent intent) {
        if (ACTION_START.equals(intent.getAction())) { startTimer(context, intent); return; }
        if (ACTION_STOP.equals(intent.getAction())) { stopTimer(context, intent); return; }
        showReminder(context, intent);
        int index=intent.getIntExtra("habit_index",-1);
        if(index>=0){String name=context.getSharedPreferences("habit_reminders",Context.MODE_PRIVATE).getString("name_"+index,"Your habit");String time=context.getSharedPreferences("habit_reminders",Context.MODE_PRIVATE).getString("time_"+index,"");if(!time.isEmpty())ReminderScheduler.schedule(context,index,name,time);}
    }
    private static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm.getNotificationChannel(CHANNEL)==null){
                Uri sound=Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.habit_chime);
                AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                NotificationChannel ch=new NotificationChannel(CHANNEL,"Habit reminders",NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Gentle reminders for your habits"); ch.setSound(sound,attrs); nm.createNotificationChannel(ch);
            }
        }
    }
    private static PendingIntent actionPending(Context c, String action, int index, String habit) {
        Intent i=new Intent(c,HabitReminderReceiver.class); i.setAction(action); i.putExtra("habit_index",index); i.putExtra("habit_name",habit);
        return PendingIntent.getBroadcast(c, 12000+index+(ACTION_STOP.equals(action)?500:0), i, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static Notification.Builder builder(Context c) {
        ensureChannel(c);
        if(Build.VERSION.SDK_INT>=26)return new Notification.Builder(c,CHANNEL);
        return new Notification.Builder(c).setSound(Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.habit_chime));
    }
    private static void showReminder(Context c, Intent intent) {
        int index=intent.getIntExtra("habit_index",0); String habit=intent.getStringExtra("habit_name"); if(habit==null||habit.trim().isEmpty())habit="Your habit";
        Intent open=new Intent(c,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=builder(c).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Time for your habit").setContentText(habit+" · Ready when you are").setContentIntent(pi).setAutoCancel(true)
          .addAction(new Notification.Action.Builder(null,"Start Timer",actionPending(c,ACTION_START,index,habit)).build()).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(9000+index,n);
    }
    private static void startTimer(Context c, Intent intent) {
        int index=intent.getIntExtra("habit_index",-1); String habit=intent.getStringExtra("habit_name"); if(habit==null)habit="Your habit"; if(index<0)return;
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putLong("start_"+index,System.currentTimeMillis()).putString("habit_"+index,habit).apply();
        PendingIntent stop=actionPending(c,ACTION_STOP,index,habit);
        Notification n=builder(c).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Timer running: "+habit).setContentText("Timer is running. Stop when you finish to complete the habit.").setOngoing(true).setAutoCancel(false)
          .addAction(new Notification.Action.Builder(null,"Stop & Complete",stop).build()).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(9000+index,n);
    }
    private static void stopTimer(Context c, Intent intent) {
        int index=intent.getIntExtra("habit_index",-1); if(index<0)return;
        android.content.SharedPreferences session=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE); long start=session.getLong("start_"+index,0L); if(start==0L)return;
        long elapsed=Math.max(0,(System.currentTimeMillis()-start)/1000L);
        String habit=session.getString("habit_"+index,intent.getStringExtra("habit_name"));
        android.content.SharedPreferences statePrefs=c.getSharedPreferences(HabitWidgetProvider.PREFS,Context.MODE_PRIVATE);
        try {
            JSONObject state=new JSONObject(statePrefs.getString(HabitWidgetProvider.STATE,"{}")); JSONArray habits=state.optJSONArray("habits"); JSONObject checks=state.optJSONObject("checks"); if(checks==null)checks=new JSONObject();
            if(habits!=null&&index<habits.length()) {
                Calendar now=Calendar.getInstance(); String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(now.getTime()); int day=now.get(Calendar.DAY_OF_MONTH);
                checks.put(month+"|"+index+"|"+day,1); state.put("checks",checks); statePrefs.edit().putString(HabitWidgetProvider.STATE,state.toString()).apply(); HabitWidgetProvider.updateAll(c);
            }
        } catch(Exception ignored) {}
        session.edit().remove("start_"+index).remove("habit_"+index).putLong("last_elapsed_"+index,elapsed).apply();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(9000+index);
        ensureChannel(c);
        Notification done=builder(c).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Habit completed ✓").setContentText((habit==null?"Your habit":habit)+" · "+formatElapsed(elapsed)+" focused").setAutoCancel(true).build(); nm.notify(10000+index,done);
    }
    private static String formatElapsed(long sec){if(sec<60)return sec+" sec";long min=sec/60,rem=sec%60;if(min<60)return min+" min "+rem+" sec";return (min/60)+" hr "+(min%60)+" min";}
}

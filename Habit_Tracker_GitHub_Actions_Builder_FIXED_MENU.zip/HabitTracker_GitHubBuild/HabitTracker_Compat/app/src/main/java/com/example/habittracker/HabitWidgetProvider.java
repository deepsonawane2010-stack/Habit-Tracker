package com.example.habittracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class HabitWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "habit_widget_prefs";
    static final String STATE = "state";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateWidget(context, manager, id);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, HabitWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(name);
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.habit_widget);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String stateText = prefs.getString(STATE, "");
        int total = 0, done = 0;
        StringBuilder habitsText = new StringBuilder();

        try {
            JSONObject state = new JSONObject(stateText);
            JSONArray habits = state.optJSONArray("habits");
            JSONObject checks = state.optJSONObject("checks");
            if (habits != null) {
                total = habits.length();
                Calendar now = Calendar.getInstance();
                String monthKey = new SimpleDateFormat("yyyy-MM", Locale.US).format(now.getTime());
                int day = now.get(Calendar.DAY_OF_MONTH);
                for (int i = 0; i < habits.length(); i++) {
                    String habit = habits.optString(i, "Habit");
                    String key = monthKey + "|" + i + "|" + day;
                    boolean isDone = checks != null && checks.optInt(key, 0) == 1;
                    if (isDone) done++;
                    if (i < 3) {
                        if (habitsText.length() > 0) habitsText.append("\n");
                        habitsText.append(isDone ? "✓ " : "○ ").append(habit);
                    }
                }
                if (habits.length() > 3) habitsText.append("\n+ ").append(habits.length() - 3).append(" more");
            }
        } catch (Exception ignored) {
            habitsText.append("Open the app to start tracking");
        }

        views.setTextViewText(R.id.widget_progress, "Today: " + done + "/" + total);
        views.setTextViewText(R.id.widget_habits, habitsText.length() == 0 ? "Add habits in the app" : habitsText.toString());

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pending);
        views.setOnClickPendingIntent(R.id.widget_open, pending);
        manager.updateAppWidget(id, views);
    }
}

# Habit Tracker — Today's Tasks Widget

This Android project includes:
- Daily habits, monthly progress, and calendar/event tabs.
- A Today's Tasks tab inside the app with tappable checkboxes.
- An Android home-screen widget with tappable task checkboxes, daily completion, and streak.
- The widget and app share task state through Android SharedPreferences; open the app after using widget checkboxes to refresh the app view.

## Build
Use JDK 17, Android SDK platform 33, Android Gradle Plugin 8.5.2, and Gradle 8.7. The GitHub Actions workflow can build the debug APK after the project folder is placed at repository root.

## Add the widget to Android home screen
After installing the APK, long-press an empty area of the phone's home screen, choose Widgets, find Habit Tracker, then drag Today's Tasks onto the home screen. Widget availability and layout depend on the launcher and Android version.

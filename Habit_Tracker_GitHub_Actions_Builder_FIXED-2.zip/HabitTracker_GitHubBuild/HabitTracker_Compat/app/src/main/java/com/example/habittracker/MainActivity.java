package com.example.habittracker;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new WidgetBridge(), "AndroidWidget");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            String raw = getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).getString(HabitWidgetProvider.STATE, "");
            if (raw != null && !raw.isEmpty()) webView.evaluateJavascript("if(window.applyNativeState)window.applyNativeState(" + JSONObject.quote(raw) + ")", null);
        }
    }
    private class WidgetBridge {
        @JavascriptInterface public String getState() {
            return getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).getString(HabitWidgetProvider.STATE, "");
        }
        @JavascriptInterface public void syncState(String json) {
            getSharedPreferences(HabitWidgetProvider.PREFS, MODE_PRIVATE).edit().putString(HabitWidgetProvider.STATE, json).apply();
            HabitWidgetProvider.updateAll(MainActivity.this);
        }
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
